Zero Live - Android TV WebView project

මෙය Android TV සඳහා website wrapper app project එකකි.
Website: https://zero.viulk.xyz/

APK එක build කිරීමට:
1. Android Studio ස්ථාපනය කර මෙම project folder එක Open කරන්න.
2. Gradle sync අවසන් වනතුරු ඉන්න.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) තෝරන්න.
4. app/build/outputs/apk/debug/app-debug.apk ගොනුව ලැබේ.
5. APK එක ඔබේ TV එකට ස්ථාපනය කිරීමට TV නිෂ්පාදකයාගේ නිල ක්‍රමය භාවිතා කරන්න.

සටහන්:
- Internet connection අවශ්‍යයි.
- Website එක TV WebView එකට ගැළපීම, DRM/video playback, login, popups සහ remote navigation
  එම website එකේ implementation එක මත රඳා පවතී.
- මෙම project එක website එකේ නම/අන්තර්ගතය හෝ හිමිකම වෙනස් නොකරයි.
- මෙය source project එකකි; සකස් කළ APK binary එකක් නොවේ.
